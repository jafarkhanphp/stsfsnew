<?php 
echo "<font size='2' face='Consolas'><font color='black'>Patch By All Kun | Defa Squad</font><b>";
?>