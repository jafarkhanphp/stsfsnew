<div class="footer-bar">
    <div class="container-fluid">
      <div class="col-sm-12">
        <div class="footer-bar-top">
          <div class="row">
            <div class="col-md-2 col-sm-3">
              <p > <span>About Us</span><strong> My Life Vision Pvt. Ltd.</strong></p>
            </div>
            <div class="col-md-2 col-sm-3">
              <p > <span>telephone</span> <strong> +91 0000000000</strong> </p>
            </div>
            <div class="col-md-2 col-sm-6">
              <p > <span>Support</span> <strong>support@mylifevision.co.in</strong> </p>
            </div>
            <div class="col-md-2 col-sm-6">
              <p > <span>Enquiry</span> <strong>info@mylifevision.co.in</strong> </p>
            </div>
            <div class="col-md-4 col-sm-6">
              <nav class="social-nav">
                <ul>
                  <li>Follow us on</li>
                  <li><a href="#"><i class="fa fa-facebook  fa-lg"></i> </a></li>
                  <li><a href="#"><i class="fa fa-twitter  fa-lg"></i> </a></li>
                  <li><a href="#"> <i class="fa fa-linkedin fa-lg"></i> </a></li>
                  <li><a href="#"> <i class="fa fa-youtube fa-lg"></i> </a></li>
                </ul>
              </nav>
              <!-- End .pl-social -->
            </div>
          </div>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="col-sm-12">
        <div class="footer-bar-middle" >
          
          <nav class="site-nav">
            <ul>
              <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/site/index" id="home"> Home </a></li>
              <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/site/about" id="about"> About us</a> </li>
              <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/site/opportunity" id="opportunity"> Opportunity</a></li>
              <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/site/legals" id="legals"> Legals</a></li>
			  <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/site/downloads" id="downloads"> Downloads</a></li>
              <li><a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/site/contact" id="contact"> Contact us</a></li>
            </ul>
          </nav>
        </div>
      </div>
      <div class="clearfix"></div>
    </div>
    <!-- -->
    <div class="footer-bar-bottom">
      <p class="copy">Copyright © 2017-2018 All Rights Reserved at <span>My Life Vision Private Limited</span></p>
    </div>
    <a href="#" id="goTop"><i class="fa fa-angle-up" aria-hidden="true"></i>top</a> </div>