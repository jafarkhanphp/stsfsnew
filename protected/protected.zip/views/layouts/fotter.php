<div class="footer clearfix">
			<div class="footer-inner">
				
			</div>
			<div class="footer-items">
				<span class="go-top"><i class="clip-chevron-up"></i></span>
			</div>
		</div>