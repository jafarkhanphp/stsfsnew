
<tbody>
  <tr class="odd gradeX">
        <td><?php echo $data->Status=='0'?'Not Used':'Used'; ?></td>
        <td><?php echo CHtml::encode($data->PinNo); ?></td>
        <td><?php echo CHtml::encode($data->issued_rid); ?></td>
        <td><?php echo $data->issued_date=='0000-00-00'?'':date('d F Y', strtotime($data->issued_date)); ?></td>
        <td><?php echo date('d F Y', strtotime($data->created)); ?></td>
        <td></td>
   
  </tr>
</tbody>


