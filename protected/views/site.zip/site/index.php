<!doctype html>
<html>


<head>
<meta charset="utf-8">
<title>My Life Vision | Let's build the future together with wealth &amp; health </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/img/favicon.ico"/>
<!--css styles -->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/css/custom_styles.css">
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/css/responsive_styles.css">
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/css/bootstrap.min.css">	
<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/css/browser.css" />
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/css/font-awesome.min.css">
<!--nav styles-->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/css/nav.css">
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/css/resnav.css">
<!-- Scripts -->
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/js/jquery.min.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/js/bootstrap.min.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/js/custom_js.js"></script>
<!--Plugins-->
<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/model-popup/model.css" />
<!-- -->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/pageloders/loader.css">
<!-- -->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/nivo-slider/nivo.css">
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/nivo-slider/nivo-custom.css">
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/nivo-slider/nivo.js"></script>
<!-- -->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/animation/css/animate.css">
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/animation/js/wow.min.js"></script>
<script>
	wow = new WOW(
		{
			boxClass:     'wow',      // default
			animateClass: 'animated', // default
			offset:       0,          // default
			mobile:       true,       // default
			live:         true        // default
		}
	)
	wow.init();
</script>
<!-- -->
<link href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/owl-carousel/owl.theme.css" rel="stylesheet">
<link href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/owl-carousel/owl.custom.css" rel="stylesheet">
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/owl-carousel/owl.carousel.js"></script>  
<!--Fonts-->
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800" rel="stylesheet">
<!--onpage styles-->
<style type="text/css">
#level_1 li a#home {
	background:#08a093; color:#fff!important
}
#level_1 li a#home:after {
	left:0;
	width:100%; background:#fff
}
</style>
<style type="text/css">

@media only screen and (min-width: 320px) and (max-width: 767px) {
.home-abt-bar {
    background: #fff;
    padding: 50px 0px 50px 0px !important;
}
table.mytable thead > tr > th {
   font-size: 9px;
   padding:5px 2px;
   vertical-align:middle;
}
table.mytable tbody > tr > td {
   font-size: 9px;
   padding:5px 2px;
}
.home-abt-bar .col-sm-12 {
	padding:0 5px !important
}

}
</style>
 

</head>
<body>


<!--login form start -->
<?php  require_once(Yii::app()->basePath . '/views/layouts/front_menu.php');?>
<section class="slider">

  <!-- Home Slider -->
  <div id="home-slider" class="slides"> 
  <img src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/img/slide-1.jpg" alt="" title="#slider-caption-1"  />
 <img src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/img/slide-2.jpg" alt="" title="#slider-caption-2"  /> 
 
  </div>
  <!-- Caption 1 -->
  <div id="slider-caption-1" class="nivo-html-caption">
    <div class="container">
      <div class="row">
        <div class="hero-slider-content  col-xs-12">
          <h1 class="wow animated zoomIn" data-wow-duration="1s" data-wow-delay="0.5s">Welcome !</h1>
          <p class="wow animated fadeInUp" data-wow-duration="1s" data-wow-delay="1s">My Life Vision - Let's build the future together with wealth & health </p>
          <a href="#" class="wow animated zoomIn" data-wow-duration="1s" data-wow-delay="1.5s">Know more</a> </div>
      </div>
    </div>
  </div>
  <!-- Caption 2 -->
  <div id="slider-caption-2" class="nivo-html-caption">
    <div class="container">
      <div class="row">
        <div class="hero-slider-content col-xs-12">
          <h1 class="wow animated zoomIn" data-wow-duration="1s" data-wow-delay="0.5s">Our Products</h1>
          <p class="wow animated fadeInUp" data-wow-duration="1s" data-wow-delay="1s">We have wide range of Products for you.</p>
          <a href="#" class="wow animated zoomIn" data-wow-duration="1s" data-wow-delay="1.5s">Know more</a> </div>
      </div>
    </div>
  </div>
 
   
</section >
<script  > 
$('#home-slider').nivoSlider({
	manualAdvance:false,
    directionNav: true,
    animSpeed: 1000,
    effect: 'sliceDown',
    slices: 18,
    pauseTime: 5000,
    pauseOnHover: false,
    controlNav: false,
    prevText: '<i class="fa fa-angle-left"></i>',
    nextText: '<i class="fa fa-angle-right"></i>' 
}); 
</script>

<!-- -->
<section class="contents"  >
<div class="container">
<div class=" icon-bar">    
        <div class="col-sm-3 no-padding"  style="background:#0068b5"  >
          <div class="icon-box ">
            <div class="icon"><a href=""> <i class="fa fa-calendar-o"></i></a></div>
            <div class="icon-box-body">
              <h3 style=" margin:10px 0!important;"><a href="">  News &amp; Events</a></h3>
            </div>
          </div>
        </div>
       <div class="col-sm-3 no-padding"   style="background:#094f82"  >
          <div class="icon-box ">
            <div class="icon"><a href="" target=""> <i class="fa fa-shield"></i></a></div>
            <div class="icon-box-body">
              <h3 style=" margin:10px 0!important;"> <a href="">New Smart Achievers</a></h3>
            </div>
          </div>
      </div>
        <div class="col-sm-3 no-padding"  style="background:#0068b5"   >
          <div class="icon-box ">
            <div class="icon"><a href=""> <i class="fa fa-list-ul"></i></a></div>
            <div class="icon-box-body">
              <h3 style=" margin:10px 0!important;"> <a href="">New Smart Meetings</a></h3>
            </div>
          </div>
        </div>
        
       <div class="col-sm-3 no-padding"  style="background:#094f82"   >
          <div class="icon-box ">
            <div class="icon"><a href=""> <i class="fa fa-camera" aria-hidden="true"></i> </a></div>
            <div class="icon-box-body">
              <h3 style=" margin:10px 0!important;"> <a href="">Photo Gallery</a></h3>
            </div>
          </div>
      </div>
    </div>
</div>
<!-- -->
<div class="product-slide-bar">
  <div class="container">
    <h1 class="main-head ">Our products<br>
      <span>We have wide range of Suitings and Health care products</span><span class="brdr"></span></h1>
    <div id="featured_products" class="owl-carousel">
      
        <div class="product">
        <div class="product-container">
         
          <div class="product-pic-container">
            <div class="product-pic"> <img src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/img/pr.jpg">
              <div class="product-back"></div>
            </div>
            <div class="product-btn"> <a href="#" class="view"><i class="fa fa-eye" aria-hidden="true"></i> </a> </div>
          </div>
          <!--<p class="product-price"> <span class="price-before">MRP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-now">DP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-bv"></span> </p> -->
          <p class="product-name"><a href="#">Product Name</a></p>
        </div>
      </div>
      <!-- --> 
      <div class="product">
        <div class="product-container">
         
          <div class="product-pic-container">
            <div class="product-pic"> <img src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/img/pr.jpg">
              <div class="product-back"></div>
            </div>
            <div class="product-btn"> <a href="#" class="view"><i class="fa fa-eye" aria-hidden="true"></i> </a> </div>
          </div>
          <!--<p class="product-price"> <span class="price-before">MRP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-now">DP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-bv"></span> </p> -->
          <p class="product-name"><a href="#">Product Name</a></p>
        </div>
      </div>
      <!-- --> 
      <div class="product">
        <div class="product-container">
         
          <div class="product-pic-container">
            <div class="product-pic"> <img src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/img/pr.jpg">
              <div class="product-back"></div>
            </div>
            <div class="product-btn"> <a href="#" class="view"><i class="fa fa-eye" aria-hidden="true"></i> </a> </div>
          </div>
          <!--<p class="product-price"> <span class="price-before">MRP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-now">DP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-bv"></span> </p> -->
          <p class="product-name"><a href="#">Product Name</a></p>
        </div>
      </div>
      <!-- --> 
      <div class="product">
        <div class="product-container">
         
          <div class="product-pic-container">
            <div class="product-pic"> <img src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/img/pr.jpg">
              <div class="product-back"></div>
            </div>
            <div class="product-btn"> <a href="#" class="view"><i class="fa fa-eye" aria-hidden="true"></i> </a> </div>
          </div>
          <!--<p class="product-price"> <span class="price-before">MRP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-now">DP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-bv"></span> </p> -->
          <p class="product-name"><a href="#">Product Name</a></p>
        </div>
      </div>
      <!-- --> 
      <div class="product">
        <div class="product-container">
         
          <div class="product-pic-container">
            <div class="product-pic"> <img src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/img/pr.jpg">
              <div class="product-back"></div>
            </div>
            <div class="product-btn"> <a href="#" class="view"><i class="fa fa-eye" aria-hidden="true"></i> </a> </div>
          </div>
          <!--<p class="product-price"> <span class="price-before">MRP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-now">DP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-bv"></span> </p> -->
          <p class="product-name"><a href="#">Product Name</a></p>
        </div>
      </div>
      <!-- --> 
      <div class="product">
        <div class="product-container">
         
          <div class="product-pic-container">
            <div class="product-pic"> <img src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/img/pr.jpg">
              <div class="product-back"></div>
            </div>
            <div class="product-btn"> <a href="#" class="view"><i class="fa fa-eye" aria-hidden="true"></i> </a> </div>
          </div>
          <!--<p class="product-price"> <span class="price-before">MRP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-now">DP : <i class="fa fa-inr" aria-hidden="true"></i> 0</span> <span class="price-bv"></span> </p> -->
          <p class="product-name"><a href="#">Product Name</a></p>
        </div>
      </div>
      <!-- --> 
      
    </div>
    <script>
	$(document).ready(function() {
	  $("#featured_products").owlCarousel({
		items : 4,
		lazyLoad : true,
		navigation : true,
		pagination : false,
		slideSpeed : 800,
        autoPlay: 2000,
		stopOnHover : true,
		autoplayTimeout:1000, 
		//itemsMobile : [767, 1], 
		itemsTablet : [991, 3], 
		itemsDesktop : [1199, 4],    
	  });
	
	});
	 </script>
  </div>
</div>
<!-- -->
<div class="home-abt-bar">
<div class="container">
<img src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/img/reg.png" class="img-responsive center-block"> 
	<!--<h2 class="joining">Joining Package Rs. 2500/-</h2>-->
    <div class="row">
    	<div class="col-sm-12">
		<p style="font-weight: bold;color: red !important;">Level Income: </p>
        	<div class="table-responsive">
    	<table cellspacing="0" cellpadding="0" class="table table-bordered table-condensed table-hover mytable table-striped">
          <thead>
          <tr>
            <th>Level</th>
            <th>Joining</th>
            <th>Bonus</th>
            <th>Direct <br class="visible-xs">
              Active Joining</th>
          </tr>
          </thead>
          <tbody>
            <?php foreach($plan as $key=>$plan){?>
          <tr>
            <td><?php echo $key+1;?></td>
            <td><?php echo $plan['joining'];?></td>
            <td><?php echo $plan['bonus'];?> /-</td>
            <td><?php echo $plan['direct_active_joining'];?></td>
          </tr>
           <?php }?>
         
        
          </tbody>
        </table>
        
        <br>



    </div>
        </div>
		
		<div class="col-sm-12">
		<p style="font-weight: bold;color: red !important;">Team Work Income: </p>
        	<div class="table-responsive">
    	<table cellspacing="0" cellpadding="0" class="table table-bordered table-condensed table-hover mytable table-striped">
          <thead>
          <tr>
            <th>S. No.</th>
            <th>Joining Amount</th>
            <th>Income(%)</th>
            <th>Income Each 2 Joining</th>
          </tr>
          </thead>
          <tbody>
          <tr>
            <td>1</td>
            <td>2500</td>
            <td>5%</td>
            <td>Rs. 250/-</td>
          </tr>
          <tr>
            <td>2</td>
            <td>2500</td>
            <td>4%</td>
            <td>Rs. 400/-</td>
          </tr>
          <tr style="background: #ff8400;">
            <td>3</td>
            <td>2500</td>
            <td>3%</td>
            <td >Rs. 600/-</td>
          </tr>
          <tr>
            <td>4</td>
            <td>2500</td>
            <td>2%</td>
            <td>Rs. 800/-</td>
          </tr>
          <tr>
            <td>5</td>
            <td>2500</td>
            <td>1%</td>
            <td>Rs. 800/-</td>
          </tr>
          <tr>
            <td>6</td>
            <td>2500</td>
            <td>1%</td>
            <td>Rs. 1600/-</td>
          </tr>
          <tr style="background: #ff8400;">
            <td>7</td>
            <td>2500</td>
            <td>1%</td>
            <td>Rs. 3200/-</td>
          </tr>
          <tr>
            <td>8</td>
            <td>2500</td>
            <td>1%</td>
            <td>Rs. 6400/-</td>
          </tr>
          <tr >
            <td>9</td>
            <td>2500</td>
            <td>1%</td>
            <td>Rs. 12,800/-</td>
          </tr>
          <tr>
            <td>10</td>
            <td>2500</td>
            <td>1%</td>
            <td >Rs. 25,600/-</td>
          </tr>
          <tr style="background: #ff8400;">
            <td>11</td>
            <td>2500</td>
            <td>1%</td>
            <td >Rs. 51,200/-</td>
          </tr>
          <tr>
            <td>12</td>
            <td>2500</td>
            <td>1%</td>
            <td >Rs. 1,02,400/-</td>
          </tr>
		  <tr>
		  <td colspan="4"><strong> After 12 upword direct sponsor get unlimited income with 0.5%</strong></td>
		  </tr>

          </tbody>
        </table>
        
        <br>



    </div>
        </div>
		
     <div class="col-sm-12">   
    <p style="font-weight: bold;color: red !important;">Terms &amp; Conditions: </p>
    
    
    <ul  class="mylist">
      <li>Closing every monday and Payout distributed on every wednesday.</li>
      <li>Pancard necessary at the time of joining.</li>
      <li>After joining payment not refunded.</li>
      <li>Deduction 5% handling charges will be applicable on each payout.</li>
      <li>TDS 5% will be deductedted each payout and without pancard will be 20%.</li>
      <li>Any new joining comlete 2 level in first startup week with 2 direct sponser then they will get both week payout.</li>
      <li>Team work(direct sponsor) income will be release either level complete or not. </li>
      <li>KYC documents(Voter ID, Aadhar, Pancard etc.) are compulsary.</li>
      <li>Earn all incentive must to follow business plan terms & conditions.</li>
    </ul>
  
    </div>
	</div>
      
	
   
    
                            
    </div></div>

</section>

<!-- -->
<footer>
  <?php  require_once(Yii::app()->basePath . '/views/layouts/front_footer.php');?>
</footer>
<!-- -->
<div class="md-overlay"></div>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/model-popup/classie.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/model-popup/modalEffects.js"></script>
<!-- -->
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/scroll/jquery.nicescroll.min.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/scroll/jquery.fancybox.pack.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/scroll/skrollr.min.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/plugins/scroll/jquery.appear.js"></script>
<script type="text/javascript">
	 //nicescroll
	$("html").niceScroll({zindex:999,cursorborder:"",cursorborderradius:"2px",cursorcolor:"#ccc",cursoropacitymin:1});
	function initNice() {
		if($(window).innerWidth() <= 960) {
			$('html').niceScroll().remove();
		} else {
			$("html").niceScroll({zindex:999,cursorborder:"",cursorborderradius:"2px",cursorcolor:"#ccc",cursoropacitymin:1});
		}
	}
	$(window).load(initNice);
	$(window).resize(initNice);
</script>
</body>

<!-- Mirrored from mysmartvision.co.in/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 04 Nov 2017 07:37:33 GMT -->
</html>
