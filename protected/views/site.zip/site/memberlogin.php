

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<title>New Registration |My Life Vision | Let's build the future together with wealth & health
</title>
<!-- Bootstrap 3.3.5 -->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/admin-css/bootstrap.min.css" />
<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/admin-css/font-awesome.min.css" />
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/admin-css/admin.css" />
<!-- Skins -->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/admin-css/skin.css" />
<!-- iCheck -->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/frontend/admin-plugins/iCheck/square/blue.css" />
<!--[if lt IE 9]>
<script src="admin-js/html5shiv.min.js"></script>
<script src="admin-js/respond.min.js"></script>
<![endif]-->
</head>
<body class="hold-transition login-page">
<form name="form1" method="post" action="http://mysmartvision.co.in/Dashboard/memberlogin.aspx" id="form1">
<div>
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwULLTEwNjY5NDA1NTcPZBYCAgMPZBYEAgEPFgIeBXN0eWxlBQpkaXNwbGF5OiI7FgICAQ8WBB4JaW5uZXJodG1sZR8ABQ1kaXNwbGF5Om5vbmU7ZAIDDxYCHwAFDWRpc3BsYXk6bm9uZTsWBAIBDxYEHwFlHwAFDWRpc3BsYXk6bm9uZTtkAgMPFgQfAWUfAAUNZGlzcGxheTpub25lO2RkGwhCGBsMAhxs3HoBbbwn/2guQNiob9D0PGIv1Ukvc+8=" />
</div>

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="C7B9D914" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAA6cxq463DmL1R/JTtuj1arW87+pEDwisZbVBe+5N+qQ9zPSlu16Yx4QbiDU+dddK1N3wFxYYfWi3STRI7sJ+66Ul0B1I8Z88ajInSaWMTd3VNyZHlWcnEbwl6T6qn/zjgPgYZThRL+QdH53/KC8j2o7zoFJKber1o3EpFmdtr9xLY+fL0FlfNb4TJjCIKmHe7w/oOEd6PiAmuwoD9/nZouYYaYfGMJYoi5WmBSGq0bh0afkDI62Gkb7aab4SV8h1/9D5GqcOTTyuosbtzepfYXh+1gVJQ6+14LMNmJ3LGoUK9HD/f71PphEuhqIdPz8S/AO8iYSEiT+jGZEkyaDAhxi" />
</div>
  <div class="login-box">
    <div id="dvLogin" class="login-box-body" style="display:&quot;;">
      <div id="lblErrorMsg" class="form-group alert alert-error" style="display:none;"></div>
      <div class="form-group has-feedback">
        
        <input name="txtBxUsr" type="text" id="txtBxUsr" class="form-control" placeholder="User ID" />
        <span class="fa fa-unlock form-control-feedback"></span> </div>
      <div class="form-group has-feedback">
        
        <input name="txtPwd" type="password" id="txtPwd" class="form-control" placeholder="Password" />
        <span class="fa fa-key form-control-feedback"></span> </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
            <input type="checkbox">
            Remember Me </label>
          </div>
        </div>
        <div class="col-xs-4">
          
          <input type="submit" name="Submit" value="Log In" id="Submit" class="btn btn-primary btn-block btn-flat" />
        </div>
      </div>
      <a href="">Forgot password ?</a> <a href="" class="text-center" style="float:right;display:none;">New Registration</a> </div>
         <div id="dvForgotPswd" class="login-box-body" style="display:none;">
    <p class="login-box-msg">Forgot Password? Get help here.</p>
    
<div id="lblFPError" class="form-group alert alert-error" style="display:none;"></div>
<div id="lblFPSuccess" class="form-group alert alert-success" style="display:none;"></div>
      <div class="form-group has-feedback">
        
        <input name="txtFPUserID" type="text" id="txtFPUserID" class="form-control" placeholder="User ID" />
        <span class="fa fa-unlock form-control-feedback"></span> </div>
    
      <div class="row">
      
        <div class="col-xs-4">
          
          
          <input type="submit" name="btnFPSbmt" value="Submit" id="btnFPSbmt" class="btn btn-primary btn-block btn-flat" />
        </div>
          

          
        
      </div>
                          <label>
           <strong style="color:Red;">Note : </strong><br />
a ) Your Password will be sent on your registered Mobile number or Email ID. <br />
b ) If you don't receive Email or SMS within one hour please contact our support center to send new password. </label>
<br />
      <a href="" id="aLogin">Click Here to Login.</a>
      
      
<input type="hidden" name="hfMobl" id="hfMobl" />
            <input type="hidden" name="hfEmail" id="hfEmail" />
            <input type="hidden" name="hfGenTime" id="hfGenTime" />
            <input type="hidden" name="hfIDNO" id="hfIDNO" />
            <input type="hidden" name="hfName" id="hfName" />
            <input type="hidden" name="hfPswd" id="hfPswd" />
            <input type="hidden" name="hfIP" id="hfIP" />
            <input type="hidden" name="hfFormNo" id="hfFormNo" />
        
    </div>

  </div>
  <!-- jQuery 2.1.4 -->
 <script language="javascript" type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/js/generalEvent.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/js/jquery-1.4.2.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/js/jquery-1.6.min.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/js/JScript2.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/frontend/js/jquery.min.js"></script>
  <script>
      $(function () {
          $('input').iCheck({
              checkboxClass: 'icheckbox_square-blue',
              radioClass: 'iradio_square-blue',
              increaseArea: '20%' // optional
          });
      });
</script>
</form>
</body>


</html>